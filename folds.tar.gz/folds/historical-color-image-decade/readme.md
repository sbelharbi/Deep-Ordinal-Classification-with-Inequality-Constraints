Format: relative path to the image, class (decade, str) 
