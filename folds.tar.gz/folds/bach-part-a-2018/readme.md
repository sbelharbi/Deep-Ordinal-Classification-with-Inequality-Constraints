csv format:
relative path to the image file, class (string)
Example:
ICIAR2018_BACH_Challenge/Photos/Normal/n047.tif, 'Normal'
There are four classes: normal, benign, in situ, and invasive.
The class of the sample may be infered from the parent folder of the image (in the example above:
 Normal:
Normal: class 'normal'
Benign: class 'benign'
InSitu: class 'in situ'
Invasive: class 'invasive'