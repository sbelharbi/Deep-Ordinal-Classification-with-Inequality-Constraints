Format: relative path to the image, class (age) 
